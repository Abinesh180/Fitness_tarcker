function appendElements(){
    $.ajax({
        url: 'Activity',
        method: 'GET',
        dataType: 'json',
        success: function (jsonData) {
			// Convert the original data to the desired format
			var data = jsonData.data.reduce(function (result, item) {
			  var month = item.month;
			  var value = item.value;
			
			  var entry = {};
			  entry[month] = value;
			
			  result.push(entry);
			
			  return result;
			}, []);

// Display the converted data
			
		
            i=0;
            for(const [key, value] of Object.entries(data)){
                var parentDiv=document.createElement('div');
                parentDiv.className='bar-holds';
                parentDiv.id='borholds'+i;
                var childDiv1=document.createElement('div');
                childDiv1.className='bar'
                var childDiv2=document.createElement('div');
                childDiv2.className='mini-bar';
                var childDiv3=document.createElement('h5');
                var childDiv4=document.createElement('div');
                childDiv4.className='bar-period';
                childDiv4.id='barperiod'+i;
                childDiv3.className='p-text';
                childDiv4.textContent=`${key}`;
                childDiv2.appendChild(childDiv3);
                childDiv1.appendChild(childDiv2);
                parentDiv.appendChild(childDiv1);
                parentDiv.appendChild(childDiv4);
                var newdiv=document.querySelector('.bars');
                newdiv.appendChild(parentDiv);
                i++;
            }
        }
    });
        }
        
        function add(){
            document.querySelector(".btn").style.display='none';
            $.ajax({
                url: 'Activity',
                method: 'GET',
                dataType: 'json',
                success: function (jsonData) {
                    var data = jsonData.data.reduce(function (result, item) {
					  var month = item.month;
					  var value = item.value;
					
					  result[month] = value;
					
					  return result;
					}, {});
                    i=0
                    console.log(data);
                    pr=[];
                  	
                    document.getElementById('peri').style.display='block'
                    document.getElementById('act').style.display='block'
                    for([key,value] of Object.entries(data)){
                        document.getElementById('barperiod'+i).style.display='block'
                        document.getElementById('borholds'+i).style.display='block'    
                        pr.push(value);
                        i++;
                    }
        			console.log(pr);
                    const element=document.getElementsByClassName("bar");
                    console.log(element[0]);
                    var e;
                    for(i=0;i<Object.entries(data).length;i++){
                        setTimeout(function (ele,i) {
                            var e=ele.children[0];
                            setHeight=((pr[i]/75)*100);
                            e.querySelector('.p-text').textContent=pr[i]+'%';
                            e.style.height=setHeight+'px';
                        }, 100,element[i],i);
                    }    
                }
            })
        };
        function circularBar(){
            let data;
            $.ajax({
                url: 'Overview',
                method: 'GET',
                dataType: 'json',
                success: function (jsonData) {
					var data = {
					  "total": jsonData.data.total , // Example modification to 'total'
					
					  "calories_burn": [
					    (jsonData.data.calburn + 0.16).toFixed(2),
					    (jsonData.data.calinc + 2.66).toFixed(2)
					  ],
					
					  "protiens": [
					    (jsonData.data.protein + 1.07).toFixed(2),
					    (jsonData.data.proinc + 0.615).toFixed(2)
					  ],
					
					  "crabs": [
					    (jsonData.data.crabs + 1.76).toFixed(2),
					    (jsonData.data.crabinc + 1.27).toFixed(2)
					  ]
					};
                    let targetValue=document.querySelector('.progress-value');
                    let circularBar=document.querySelector('.circular-progress');
                    let initialValue=0,endValue=data['total'],speed=30;
                    
                    document.querySelector('.o-child2 h3').textContent=`${data['calories_burn'][0]}`
                    document.querySelector('.o-child2 p').textContent=`+${data['calories_burn'][1]}`
                    document.querySelector('.o-child2 h3').textContent=`${data['protiens'][0]}`
                    document.querySelector('.o-child2 p').textContent=`+${data['protiens'][1]}`
                    document.querySelector('.o-child2 h3').textContent=`${data['crabs'][0]}`
                    document.querySelector('.o-child2 p').textContent=`+${data['crabs'][1]}`
            
                    let Progress=setInterval(()=>{
                        initialValue++;
                        circularBar.style.background=`conic-gradient(rgb(102, 255, 51) ${(initialValue *3.6)}deg, rgb(198, 255, 179) 0deg)`;
                        targetValue.textContent=`${initialValue}%`;
                        if(initialValue==endValue) {
                            clearInterval(Progress);
                        }
                    },speed);
                }
            })
            

        }
        function wCircularBar() {
            let data;
            $.ajax({
                url: 'Workout',
                method: 'GET',
                dataType: 'json',
                success: function (originalData) {
                    endValue=[]
                   // data=jsonData[jsonData['user']]['workout'];
                   
					// Define a mapping of the original keys to the new keys
					var keyMapping = {
					  "legcurr": "legpress",
					  "legtar": "legpress",
					  "maccurr": "machinefly",
					  "mactar": "machinefly",
					  "smicurr": "smithpress",
					  "smitar": "smithpress",
					  "checurr": "chestpress",
					  "chetar": "chestpress"
					};
					
					// Create an object to store the converted data
					var data = {};
					
					// Iterate through the original data and map to the new structure
					for (var key in originalData) {
					  var newKey = keyMapping[key];
					  if (!data[newKey]) {
					    data[newKey] = {};
					  }
					
					  if (key.endsWith("curr")) {
					    data[newKey]["current"] = parseInt(originalData[key]);
					  } else if (key.endsWith("tar")) {
					    data[newKey]["target"] = parseInt(originalData[key]);
					  }
					}
					
					// Display the converted data
					jsonData=JSON.stringify({ "workout": data }, null, 2);
					i=0;
                    for([key,value] of Object.entries(jsonData)){
                        num1=value['current'];
                        num2=value['target'];
                        endValue[i]=parseInt((num1/num2)*100);
                        i++;
                    }
                    console.log(data);
                    i=0;
                    for([key,value] of Object.entries(data)){
                        num1=value['current'];
                        num2=value['target'];
                        endValue[i]=parseInt((num1/num2)*100);
                        i++;
                    }
                    let targetValues = document.getElementsByClassName('w-progress-value');
                    let circularBars = document.getElementsByClassName('w-circular-progress');
                    let curr=document.getElementsByClassName('curr');
                    let targ=document.getElementsByClassName('targ');
                    let speed = 30;
                    let color=['#661aff','#ff3333','#ff1aff','#e69900'];
                    let arr=["legpress","machinefly","smithpress","chestpress"];
                    
                    for (let i = 0; i <Object.entries(data).length; i++) {
                        let initialValue = 0;
                        dict=data[arr[i]];
                        (function (tvalue, cbar,endValue,color,targ,curr,arr,dict) {
                            let interval = setInterval(() => {
                                initialValue++;
                                curr.innerHTML=dict['current'];
                                targ.innerHTML=dict['target'];
                                cbar.style.background = `conic-gradient(${color[i]} ${initialValue * 3.6}deg, rgb(204, 179, 255) 0deg)`;
                                tvalue.textContent = `${initialValue}%`;
                                tvalue.style.color="black";

                                if (initialValue === endValue[i]) {
                                    clearInterval(interval);
                                }
                            }, speed);
                        })(targetValues[i], circularBars[i],endValue,color,targ[i],curr[i],arr,dict);
                    }
                }}
            )
        }
