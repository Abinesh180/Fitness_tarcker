package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Overview
 */
@WebServlet("/Overview")
public class Overview extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Overview() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        try {
            // Load the PostgreSQL JDBC driver
            try{
            	Class.forName("org.postgresql.Driver");
            	
            }catch(Exception e) {
            	throw e;
            }

            // Establish a connection to the PostgreSQL database
            String url = "jdbc:postgresql://localhost:5432/Abinesh";
            String username = "postgres";
            String password = "abinesh";
            Connection connection = DriverManager.getConnection(url, username, password);

            // Perform database operations
            String sql = "select total,calburn,calinc,protein,proinc,crabs,crabinc from \"user\".overview where user_id=1";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                ResultSet resultSet = statement.executeQuery();
                // Process the ResultSet and generate JSON response
                // (You need to implement this based on your requirements)
                if (resultSet.next()) {
                    int total = resultSet.getInt("total");
                    int calburn = resultSet.getInt("calburn");
                    int calinc = resultSet.getInt("calinc");
                    int protein = resultSet.getInt("protein");
                    int proinc = resultSet.getInt("proinc");
                    int crabs = resultSet.getInt("crabs");
                    int crabinc = resultSet.getInt("crabinc");

                    // Construct JSON format
                    String jsonResult = String.format("{\"data\": {" +
                            "\"total\": %d," +
                            "\"calburn\": %d," +
                            "\"calinc\": %d," +
                            "\"protein\": %d," +
                            "\"proinc\": %d," +
                            "\"crabs\": %d," +
                            "\"crabinc\": %d" +
                            "}}", total, calburn, calinc, protein, proinc, crabs, crabinc);

                    // Send the JSON response
                    out.println(jsonResult);
                }
                    // Close resources
                resultSet.close();
                statement.close();
                connection.close();

            }
            

            // Close the database connection
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
            // Handle exceptions appropriately
        }

        out.close();
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
