package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Myservlet
 */
@WebServlet("/Workout")
public class Workout extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Workout() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        try {
            // Load the PostgreSQL JDBC driver
            try{
            	Class.forName("org.postgresql.Driver");
            	
            }catch(Exception e) {
            	throw e;
            }

            // Establish a connection to the PostgreSQL database
            String url = "jdbc:postgresql://localhost:5432/Abinesh";
            String username = "postgres";
            String password = "abinesh";
            Connection connection = DriverManager.getConnection(url, username, password);

            // Perform database operations
            String sql = "SELECT * FROM \"user\".workout where user_id=1";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                ResultSet resultSet = statement.executeQuery();
                // Process the ResultSet and generate JSON response
                // (You need to implement this based on your requirements)
                while (resultSet.next()) {
                    String legcurr = resultSet.getString("legcurr");
                    String legtar = resultSet.getString("legtar");
                    String maccurr = resultSet.getString("maccurr");
                    String mactar = resultSet.getString("mactar");
                    String smicurr = resultSet.getString("smicurr");
                    String smitar = resultSet.getString("smitar");
                    String checurr = resultSet.getString("checurr");
                    String chetar = resultSet.getString("chetar");

                    // Create a JSON object for each row
                    String jsonRow = String.format("{\"legcurr\":\"%s\",\"legtar\":\"%s\",\"maccurr\":\"%s\",\"mactar\":\"%s\",\"smicurr\":\"%s\",\"smitar\":\"%s\",\"checurr\":\"%s\",\"chetar\":\"%s\"}",
                            legcurr, legtar, maccurr, mactar, smicurr, smitar, checurr, chetar);

                    out.println(jsonRow);
                }
                    // Close resources
                resultSet.close();
                statement.close();
                connection.close();

            }
            

            // Close the database connection
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
            // Handle exceptions appropriately
        }

        out.close();
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
