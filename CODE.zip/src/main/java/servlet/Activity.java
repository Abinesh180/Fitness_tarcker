package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Activity
 */
@WebServlet("/Activity")
public class Activity extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Activity() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        try {
            // Load the PostgreSQL JDBC driver
            try{
            	Class.forName("org.postgresql.Driver");
            	
            }catch(Exception e) {
            	throw e;
            }

            // Establish a connection to the PostgreSQL database
            String url = "jdbc:postgresql://localhost:5432/Abinesh";
            String username = "postgres";
            String password = "abinesh";
            Connection connection = DriverManager.getConnection(url, username, password);

            // Perform database operations
            String sql = "select month,value from \"user\".year where \"year\" = 2023 and user_id =1";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                ResultSet resultSet = statement.executeQuery();
                // Process the ResultSet and generate JSON response
                // (You need to implement this based on your requirements)
                StringBuilder jsonResult = new StringBuilder("{ \"data\": [");
                while (resultSet.next()) {
                    String month = resultSet.getString(1); // Assuming the month is in the first column
                    int value = resultSet.getInt(2); // Assuming the value is in the second column

                    jsonResult.append("{ \"month\": \"").append(month).append("\", \"value\": ").append(value).append(" },");
                }
                

                // Remove the trailing comma and close the JSON structure
                if (jsonResult.charAt(jsonResult.length() - 1) == ',') {
                    jsonResult.deleteCharAt(jsonResult.length() - 1);
                }

                jsonResult.append("] }");
                out.write(jsonResult.toString());
                    // Close resources
                resultSet.close();
                statement.close();
                connection.close();

            }
            

            // Close the database connection
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
            // Handle exceptions appropriately
        }

        out.close();
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
